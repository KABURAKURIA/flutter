package com.example.flutter_app_074

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
