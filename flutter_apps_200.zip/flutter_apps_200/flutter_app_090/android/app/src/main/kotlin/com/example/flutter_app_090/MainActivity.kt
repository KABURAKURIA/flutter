package com.example.flutter_app_090

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
