package com.example.flutter_app_121

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
