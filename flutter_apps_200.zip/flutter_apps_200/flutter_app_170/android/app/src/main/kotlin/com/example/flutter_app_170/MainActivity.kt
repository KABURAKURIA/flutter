package com.example.flutter_app_170

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
