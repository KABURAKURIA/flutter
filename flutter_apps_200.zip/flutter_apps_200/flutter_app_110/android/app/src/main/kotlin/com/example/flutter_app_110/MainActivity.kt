package com.example.flutter_app_110

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
