package com.example.flutter_app_156

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
