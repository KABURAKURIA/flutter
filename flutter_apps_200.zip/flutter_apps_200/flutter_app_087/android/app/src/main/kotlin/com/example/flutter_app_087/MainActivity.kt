package com.example.flutter_app_087

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
